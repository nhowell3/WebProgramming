const AppColors = {
    PageBg: 'linear-gradient(to bottom, #1e2939, #030712)',
    HeaderColor: 'white',
    TextColor: '#d1d5dc',
    ContentBg: 'linear-gradient(to bottom, #050505, #040404)',
};

export default AppColors;