import GenericPage from "../components/GenericPage";

export default function HomePage({}){
    return (
        <GenericPage>
            <h1> Welcome </h1>
            <br/>
            <h3> View are database data by clicking on the navigation above </h3>
        </GenericPage>
    );
}