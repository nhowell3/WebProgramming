function isEven(number){
    if (number % 2 == 0)
        return true
    return false
}

console.log(isEven(1))
console.log(isEven(2))
console.log(isEven(3))
console.log(isEven(4))
console.log(isEven(5))