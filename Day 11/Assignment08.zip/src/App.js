import React from "react";
import CardList from "./CardList";
import "./App.css";

export default function App(){
  
  return (
    <div className="container">
      <CardList/>
    </div>
  );
}